
public class Funcionario {
    private String nome;
    private int idade;
    private double salario;

    /**
     * @return the nome
     */
    /**Define os valores principais*/
    public Funcionario(){
        this("Bruna",10,3000);
    }
    /*Insere os valores*/
    public Funcionario(String nm, int id, double sl){
        nome= nm;
        idade= id;
        salario= sl;
        
    }
   
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
}
