
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author logonubc
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    
    //Funcionario func = new Funcionario();
    public static void main(String[] args) {
       
        
        ArrayList<Funcionario> lista= new ArrayList<Funcionario>();
        
        
       lista.add(new Funcionario("Lucas", 25,9000));
       lista.add(new Funcionario("Clara",18, 6000));
       lista.add(new Funcionario("Julia",29,12000));
       
       
       for(Funcionario func:lista){
           
           System.out.println(func.getNome()+" "+func.getIdade()+" "+func.getSalario());
       
       }
        
        
        
    }
    
}
